﻿using System;

public class ChessboardGame
{
    public static void Main()
    {
        int n = int.Parse(Console.ReadLine());

        string input = Console.ReadLine();

        int blacSum = 0;
        int whiteSum = 0;

        for (int i = 0; i < input.Length; i++)
        {
            if (i >= n * n)
            {
                break;
            }

            if (i % 2 == 0 && char.IsUpper(input[i]))
            {
                whiteSum += input[i];
            }
            else if (i % 2 == 0 && char.IsLetterOrDigit(input[i]))
            {
                blacSum += input[i];
            }
            else if (i % 2 != 0 && char.IsUpper(input[i]))
            {
                blacSum += input[i];
            }
            else if (i % 2 != 0 && char.IsLetterOrDigit(input[i]))
            {
                whiteSum += input[i];
            }
        }

        if (blacSum == whiteSum)
        {
            Console.WriteLine("Equal result: {0}", whiteSum);
        }
        else
        {
            Console.WriteLine(
                "The winner is: {0} team",
                whiteSum > blacSum ? "white" : "black");

            int resultDifference = Math.Abs(whiteSum - blacSum);
            Console.WriteLine(resultDifference);
        }
    }
}