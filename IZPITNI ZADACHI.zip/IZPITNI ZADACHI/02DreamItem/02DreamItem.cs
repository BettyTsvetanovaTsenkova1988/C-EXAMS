﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02DreamItem
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] inputtext = input.Split('\\');
            string month = inputtext[0]; // месец
           decimal moneyPerHour = decimal.Parse(inputtext[1]);
           int hoursPerDay = Int32.Parse(inputtext[2]);
            decimal itemPrice = decimal.Parse(inputtext[3]);
           // Console.WriteLine("{0}",inputtext);
           // Console.WriteLine("{0}",month);
          // Console.WriteLine(month + " "+ moneyPerHour + " "+ hoursPerDay+" "+ itemPrice);
            decimal saved = 0;
           
            switch (month)
            {
                case "Jan": saved = (31 - 10) * moneyPerHour * hoursPerDay;  break;
                case "Feb": saved = (28 - 10) * moneyPerHour * hoursPerDay;  break;
                case "March": saved = (31 - 10) * moneyPerHour * hoursPerDay;  break;
                case "Apr": saved = (30 - 10) * moneyPerHour * hoursPerDay;  break;
                case "May": saved = (31 - 10) * moneyPerHour * hoursPerDay;  break;
                case "June": saved = (30 - 10) * moneyPerHour * hoursPerDay; break;
                case "July": saved = (31 - 10) * moneyPerHour * hoursPerDay;  break;
                case "Aug": saved = (31 - 10) * moneyPerHour * hoursPerDay;  break;
                case "Sept": saved = (30 - 10) * moneyPerHour * hoursPerDay;  break;
                case "Oct": saved = (31 - 10) * moneyPerHour * hoursPerDay;  break;
                case "Nov": saved = (30 - 10) * moneyPerHour * hoursPerDay;  break;
                case "Dec": saved = (31 - 10) * moneyPerHour * hoursPerDay;  break;
                default:
                    break;
            }

           

            if (saved > 700)
            {
                saved += saved * 0.10m;
            }

            decimal left = saved - itemPrice;

            if (saved >= itemPrice)
            {
                Console.WriteLine("Money left = {0:F2} leva.", left);
            }
            else
            {
                Console.WriteLine("Not enough money. {0:F2} leva needed.", Math.Abs(left));
            }

        }
    }
}
