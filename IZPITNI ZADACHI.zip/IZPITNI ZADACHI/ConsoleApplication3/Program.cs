﻿using System;

class DailyCalorieIntake
{
    static void Main()
    {
        double w = int.Parse(Console.ReadLine()) / 2.2;
        double h = int.Parse(Console.ReadLine()) * 2.54;
        int a = int.Parse(Console.ReadLine()); //age in years
        char g = char.Parse(Console.ReadLine()); //gender
        int e = int.Parse(Console.ReadLine()); //workouts per week

        double bmrM;
        if (g == 'm')
        {
            bmrM = 66.5 + (13.75 * w) + (5.003 * h) - (6.755 * a);
        }
        else
        {
            bmrM = 655 + (9.563 * w) + (1.85 * h) - (4.676 * a);
        }

        double dci;
        if (e <= 0)
        {
            dci = 1.2 * bmrM;
        }
        else if ((e >= 1) && (e <= 3))
        {
            dci = 1.375 * bmrM;
        }
        else if ((e >= 4) && (e <= 6))
        {
            dci = 1.55 * bmrM;
        }
        else if ((e >= 7) && (e <= 9))
        {
            dci = 1.725 * bmrM;
        }
        else
        {
            dci = 1.9 * bmrM;
        }

        Console.WriteLine("{0}", Math.Floor(dci));

        Console.ReadLine();
    }
}