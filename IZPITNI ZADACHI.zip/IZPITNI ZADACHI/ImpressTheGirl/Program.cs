﻿using System;

class CurrencyCheck
{
    static void Main()
    {
        double rubles = double.Parse(Console.ReadLine());
        double dolars = double.Parse(Console.ReadLine());
        double euros = double.Parse(Console.ReadLine());
        double bgB = double.Parse(Console.ReadLine());
        double bgM = double.Parse(Console.ReadLine());

        double rtoBg = (rubles / 100.00) * 3.5;
        double dtoBG = (dolars * 1.50);
        double eurtoBG = (euros * 1.95);
        double bgB1 = (bgB / 2);
        double bgM1 = bgM;

        double value1 = Math.Max(rtoBg, dtoBG);
        double value2 = Math.Max(eurtoBG, bgB1);
        double value3 = Math.Max(value1, value2);
        double value4 = Math.Max(value3, bgM1);

        Console.WriteLine("{0:F2}",Math.Ceiling(value4));
    }
}