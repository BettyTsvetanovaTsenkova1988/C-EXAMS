﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IlluminatiLock
{
    class IlluminatiLock
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("{0}{1}{0}",new string('.',n),new string('#',n));//първи ред
            Console.WriteLine("{0}{1}{0}{1}{0}", new string('.', n - 2), new string('#', 3));//червено

            for (int i = 0; i < (n/2)-2; i++)// зелено
            {
                Console.WriteLine("{0}##{1}#{2}#{1}##{0}", new string('.', (n -4) - 2 * i), new string('.',2 + 2 * i), new string('.', n - 2));
            }

            for (int j = 0; j < 2; j++)//жълта среда
            {
                Console.WriteLine(".##{0}#{1}#{0}##.",new string('.',n-2-1),new string('.',n-2));
            }

            for (int k = 0; k < (n / 2) - 2; k++)// зелено
            {
                Console.WriteLine("{0}##{1}#{2}#{1}##{0}", new string('.',3+2*k), new string('.', (n -5)- 2 * k), new string('.', n - 2));
            }

            Console.WriteLine("{0}{1}{0}{1}{0}", new string('.', n - 2), new string('#', 3));//червено
            Console.WriteLine("{0}{1}{0}", new string('.', n), new string('#', n));//първи ред
        }
    }
}
