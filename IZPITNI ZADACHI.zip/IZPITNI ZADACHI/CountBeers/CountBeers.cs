﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountBeers
{
    class CountBeers
    {
        static void Main(string[] args)
        {
            string input =string.Empty;
            int number = 0;
            int sum = 0;


            while (input != "End")
            {
                input = Console.ReadLine();
                int arr = Int32.Parse(input[0]);
                number =  Convert.ToInt32((input[0]));
                // number = int.Parse(arr[0]);
                string mesure = input[1].ToString();
               

                if (mesure == "stacks")
                {
                    sum += (number * 20);
                }
                else
                {
                    sum += number;
                }

            }
            Console.WriteLine(sum);
        }
    }
}
