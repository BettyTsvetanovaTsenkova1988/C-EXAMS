﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitBoxInBox
{
    class FitBoxInBox// НЕДОВЪРШЕНА!!!! 20 ТОЧКИ!!!
    {
        static void Main(string[] args)
        {
            int fA = int.Parse(Console.ReadLine());
            int fB = int.Parse(Console.ReadLine());
            int fC = int.Parse(Console.ReadLine());
            int sA = int.Parse(Console.ReadLine());
            int sB = int.Parse(Console.ReadLine());
            int sC = int.Parse(Console.ReadLine());
            int sumFirst = fA + fB + fC;
            int sumSecons = sA + sB + sC;



            if (fA < sA && fB < sB && fC < sC)//ако първата е по-малка
            {
                Console.WriteLine("({0}, {1}, {2}) < ({3}, {4}, {5})", fA, fB, fC, sA, sB, sC);
                Console.WriteLine("({0}, {1}, {2}) < ({3}, {4}, {5})", fA, fB, fC, sA, sC, sB);
                Console.WriteLine("({0}, {1}, {2}) < ({3}, {4}, {5})", fA, fB, fC, sB, sA, sC);
                Console.WriteLine("({0}, {1}, {2}) < ({3}, {4}, {5})", fA, fB, fC, sB, sC, sA);
                Console.WriteLine("({0}, {1}, {2}) < ({3}, {4}, {5})", fA, fB, fC, sC, sA, sB);
                Console.WriteLine("({0}, {1}, {2}) < ({3}, {4}, {5})", fA, fB, fC, sC, sB, sA);
            }
            else if (fA > sA && fB > sB && fC > sC)// аков втората е по-малка
            {
                Console.WriteLine("({0}, {1}, {2}) < ({3}, {4}, {5})", sA, sB, sC, fA, fB, fC);
                Console.WriteLine("({0}, {1}, {2}) < ({3}, {4}, {5})", sA, sB, sC, fA, fC, fB);
                Console.WriteLine("({0}, {1}, {2}) < ({3}, {4}, {5})", sA, sB, sC, fB, fA, fC);
                Console.WriteLine("({0}, {1}, {2}) < ({3}, {4}, {5})", sA, sB, sC, fB, fC, fA);
                Console.WriteLine("({0}, {1}, {2}) < ({3}, {4}, {5})", sA, sB, sC, fC, fA, fB);
                Console.WriteLine("({0}, {1}, {2}) < ({3}, {4}, {5})", sA, sB, sC, fC, fB, fA);
            }


            else if (sumFirst == sumSecons) // няма по-малка кутия
            {
                Console.WriteLine();
            }

        }
    }
}

