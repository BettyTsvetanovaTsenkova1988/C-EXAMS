﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JumpingSums
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int jump = int.Parse(Console.ReadLine());
            string[] text = input.Split(' ');
            int[] arr = new int[text.Length];
            int max = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = int.Parse(text[i]);//пълни масива от интове/взема стойностите от масива тип стринг = на входния стринг
            }

            for (int i = 0; i < arr.Length; i++)
            {
                int value = arr[i]; // стойността на елемента
                int currIndex = i; //текущ индекс, започва от нула
                int nextIndex = (value + currIndex) % arr.Length; //определя следваща позиция = на остатъка от процентното делене и гарантира, че няма да се излезе от границите на масива!!!
                int sum = 0;

                for (int j = 0; j <= jump; j++)
                {
                    sum += value; // сумира стойностите на елементите, за да намери тотала им
                    value = arr[nextIndex]; //показва каква е стойността на следващата позиция на индекса
                    currIndex = nextIndex; // премества текущия индекс на следващияр т.е., следващия индекс вече е текущ
                    nextIndex = (value + currIndex) % arr.Length;
                }
                if (sum>max)
                {
                    max = sum;
                }
            }

            Console.WriteLine("max sum = {0}", max);
        }
    }
}
