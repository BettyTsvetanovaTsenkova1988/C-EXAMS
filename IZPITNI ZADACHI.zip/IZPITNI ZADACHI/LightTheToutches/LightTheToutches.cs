﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LightTheToutches
{
    class LightTheToutches // недовършена
    {
        static void Main(string[] args)
        {
            int numOfRooms = int.Parse(Console.ReadLine());
            string pattern = Console.ReadLine();

            char[] basement = new char[numOfRooms];
            //   int patternIndex = 0;

            for (int i = 0; i < numOfRooms; i++)
            {
                //    if (patternIndex == pattern.Length)
                //  {
                //    patternIndex = 0;
                //  }

                int patternIndex = i % pattern.Length;//така се дели за да не се излезе от границите на патърна
                basement[i] = pattern[i];
            }

            int previosPosition = numOfRooms / 2;
            while (true)
            {
                string command = Console.ReadLine();
                if (command == "END")
                {
                    break;
                }

                string[] commandParts = command.Split(' ');
                string direction = commandParts[0];
                int step = int.Parse(commandParts[1] + 1);

                if (direction == "LEFT")
                {
                    step = step * -1;

                }
                int currentPos = previosPosition + step;

                if (currentPos < 0)
                {
                    currentPos = 0;
                }


                if (currentPos != previosPosition)
                {
                    if (basement[currentPos] == 'L')
                    {
                        basement[currentPos] = 'D';
                    }

                    else
                    {
                        basement[currentPos] = 'L';
                    }
                }
                previosPosition = currentPos;

                command = Console.ReadLine();
            }
            int count = 0;
            foreach (char c in basement)
            {
                if (c == 'D')
                {
                    count++;
                }
            }

            Console.WriteLine(count * 'D');


        }
    }
}
