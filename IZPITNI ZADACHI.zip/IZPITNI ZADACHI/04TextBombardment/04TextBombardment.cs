﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04TextBombardment
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            
            string textN = input.Replace(" ", ""); //маха интервалите от входа
            
            int c = int.Parse(Console.ReadLine()); //широчината на матрицата
            string bombardment = (Console.ReadLine());
            int[] bomb = bombardment.Split(' ').Select(int.Parse).ToArray(); //масив с цифрите на колоните
            
            int count = 0; //брои колко са чаровете
            
            foreach (var item in input)
            {
                count++;
            }

            int r = (int)(Math.Ceiling((double)count / c)); //брои колко са редовете

            List<char> neshto = new List<char> { };

            for (int i = 0; i < r*c; i+=c) //върти четири пъти през 10
            {
                for (int j = 0; j < c; j++) //върти девет пъти
                {
                   
                    neshto.Add(input[0+j]); //пълни от 0 до 9
                    
                }
               
                
            }
            foreach (var item in neshto)
            {
                Console.Write(item);
            }
           

           
                
            









           

           
        }
    }
}
