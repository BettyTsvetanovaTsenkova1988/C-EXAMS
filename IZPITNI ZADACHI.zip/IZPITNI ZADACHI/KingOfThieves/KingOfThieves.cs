﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KingOfThieves
{
    class KingOfThieves
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            char c = char.Parse(Console.ReadLine());

            Console.WriteLine("{0}{1}{0}",new string('-',n/2),new string(c,1)); //първи ред

            for (int i = 0; i < n/2-1; i++)
            {
                Console.WriteLine("{0}{1}{0}",new string('-',n/2-1-i),new string(c,3+i+i));
            }

            Console.WriteLine(new string(c,n));//среден ред
           

            for (int j = 0; j < (n/2)-1; j++)
            {
                Console.WriteLine("{0}{1}{0}",new string('-',1+j),new string(c,n-2-j-j));
            }

            Console.WriteLine("{0}{1}{0}", new string('-', n / 2), new string(c, 1)); //последен ред
        }
    }
}
