﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roklq
{
    class Roklq
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("{0}{1}{0}",new string('.',n),new string('*',n));

            for (int i = 0; i < n/2; i++)// жълто
            {
                Console.WriteLine("{0}*{1}*{0}",new string('.',n-2 -2*i),new string('.',n+2+4*i));
            }
            Console.WriteLine("*{0}*{1}*{0}*", new string('.', n - 2), new string('.', n));//червено

            for (int k = 0; k < n/2-1; k++)//зелено
            {
                Console.WriteLine("*{0}*{1}*{2}*{1}*{0}*",new string('.',n-4-2*k),new string('.',1+2*k),new string('.',n));
            }

            for (int m = 0; m < n-1; m++)//фуста
            {
                Console.WriteLine("{0}*{1}*{0}",new string('.',n-1-m),new string('.',n+2*m));
            }

            Console.WriteLine("{0}",new string('*',n*3));

        }
    }
}
