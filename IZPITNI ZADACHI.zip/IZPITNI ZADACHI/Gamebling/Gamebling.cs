﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gamebling
{
    class Gamebling
    {
        static void Main(string[] args)
        {
            double cash = double.Parse(Console.ReadLine());
            string hand = Console.ReadLine();

            char[] input = hand.Split(' ');//обръща входа на масив

            for (int i = 0; i < input.Length; i++)
            {
                char current = input[i];
                if (current >= '0' && current <= 9)
                {
                    
                }
            }
        }
    }
}
