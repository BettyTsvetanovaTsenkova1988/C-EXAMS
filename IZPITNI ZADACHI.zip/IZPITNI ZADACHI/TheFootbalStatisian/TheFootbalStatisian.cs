﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheFootbalStatisian
{
    class TheFootbalStatisian // НЕДОВЪРШЕНА ЗАДАЧА!!!!!!!
    {
        static void Main(string[] args)
        {
            decimal payment = decimal.Parse(Console.ReadLine());
            string input = null;
            string[] arr = input.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string teamNameOne = null;
            int pointsToAdd = 0;
            int pArsenal = 0;
            int pChelsea = 0;
            int pManchesterCity = 0;
            int pManchesterUnited = 0;
            int pLiverpool = 0;
            int pEverton = 0;
            int pSouthampton = 0;
            int pTottenham = 0;
            decimal price = payment * 1.94m;

            while (input != "End of the league.")
            {
                input = Console.ReadLine();
                string firstTeam = arr[0];
                string secondTeam = arr[1];
                string thirdTeam = arr[2];

                if (arr[1] == "X")
                {
                    pointsToAdd += 1;
                }

                else if (arr[1] == "1")
                {
                    pointsToAdd += 3;
                }
                else
                {
                    pointsToAdd += 3;
                }
                switch (teamNameOne)
                {
                    case "Arsenal": pArsenal += pointsToAdd; break;
                    case "Chelsea": pChelsea += pointsToAdd; break;
                    case "ManchesterCity": pManchesterCity += pointsToAdd; break;
                    case "ManchesterUnited": pManchesterUnited += pointsToAdd; break;
                    case "Liverpool": pLiverpool += pointsToAdd; break;
                    case "Everton": pEverton += pointsToAdd; break;
                    case "Southampton": pSouthampton += pointsToAdd; break;
                    case "Tottenham": pTottenham += pointsToAdd; break;
                    default: break;
                }





            }
            Console.WriteLine("{0:f2}lv.", price);
            Console.WriteLine("Arsenal - {0} points.", pArsenal);
            Console.WriteLine("Chelsea - {0} points.", pChelsea);
            Console.WriteLine("Everton - {0} points.", pEverton);
            Console.WriteLine("Liverpool - {0} points.", pLiverpool);
            Console.WriteLine("Manchester City - {0} points.", pManchesterCity);
            Console.WriteLine("Manchester United - {0} points.", pManchesterUnited);
            Console.WriteLine("Southampton - {0} points.", pSouthampton);
            Console.WriteLine("Tottenham - {0} points.", pTottenham);
        }
        
    }
}
