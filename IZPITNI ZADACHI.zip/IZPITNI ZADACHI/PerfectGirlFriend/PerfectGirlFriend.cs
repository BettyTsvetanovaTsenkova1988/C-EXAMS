﻿using System;

class PerfectGirlFriend
{
    static void Main(string[] args)
    {
        string input = Console.ReadLine();
        int result = 0;
        int count = 0;

        while (input != "Enough dates!")
        {
             
            string[] splitInput = input.Split('\\');
            string day = splitInput[0];
            string phone = splitInput[1];
            string bra = splitInput[2];
            string name = splitInput[3];
            switch (day)
            {
                case "Monday":    result += 1; break;
                case "Tuesday":   result += 2; break;
                case "Wednesday": result += 3; break;
                case "Thursday":  result += 4; break;
                case "Friday":    result += 5; break;
                case "Saturday":  result += 6; break;
                case "Sunday":    result += 7; break;
                default: break;
            }

            for (int i = 0; i < phone.Length; i++)
            {
                result += phone[i] - '0';
            }

           int braSize = int.Parse(bra.Substring(0, bra.Length - 1));
            result += braSize * bra[bra.Length - 1];
            int firstLetter = name[0];
            result -= name.Length * firstLetter;

            if (result < 6000)
            {
                Console.WriteLine("Keep searching, {0} is not for you.", name);
            }
            else 
            {
                Console.WriteLine("{0} is perfect for you.",name);
                count++;
            }
            input = Console.ReadLine();
           
        }
        Console.WriteLine(count);
    }
}

