﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04ArrayMatcher
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] text = input.Split('\\');
            List<char> one = new List<char>(text[0]);
            List<char> two = new List<char>(text[1]);
            string command = text[2];
            List<char> dupl = new List<char>();

            if (command == "join")
            {
                for (int i = 0; i < two.Count; i++)
                {
                    for (int j = 0; j < one.Count; j++)
                    {
                        if (one.Contains(two[i]))
                        {
                            dupl.Add(two[i]);
                        }
                    }
                }
                dupl.Sort();
                dupl = dupl.Distinct().ToList();
                foreach (var item in dupl)
                {
                    Console.Write(item);
                }
            }

            else if (command == "right exclude")
            {
                for (int i = 0; i < two.Count; i++)
                {
                    for (int j = 0; j < one.Count; j++)
                    {
                        if (one.Contains(two[i]))
                        {
                            one.Remove(two[i]);
                        }
                    }
                }
                one.Sort();

                foreach (var item in one)
                {
                    Console.Write(item);
                }
            }

            else if (command == "left exclude")
            {
                for (int i = 0; i < one.Count; i++)
                {
                    for (int j = 0; j < two.Count; j++)
                    {
                        if (two.Contains(one[i]))
                        {
                            two.Remove(one[i]);
                        }
                    }
                }

                two.Sort();
                foreach (var item in two)
                {
                    Console.Write(item);
                }
            }
            
        }
    }
}
