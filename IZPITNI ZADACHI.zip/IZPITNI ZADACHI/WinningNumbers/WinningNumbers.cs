﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinningNumbers
{
    class WinningNumbers
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine().ToLower();
            int sumInput = 0;
            int counter = 0;


            for (int i = 0; i < input.Length; i++)
            {
                char currChar = input[i];

                if (currChar >= 'a' && currChar <= 'z')
                {
                    sumInput += currChar - 'a' + 1;
                }
            }

            for (int i = 1; i <= 9; i++)
            {
                for (int j = 1; j <= 9; j++)
                {
                    for (int k = 1; k <= 9; k++)
                    {
                        for (int l = 1; l <= 9; l++)
                        {
                            for (int m = 1; m <= 9; m++)
                            {
                                for (int n = 1; n <= 9; n++)
                                {
                                    if (i * j * k == sumInput && l * m * n == sumInput)
                                    {
                                        counter++;
                                        Console.WriteLine("{0}{1}{2}-{3}{4}{5}", i, j, k, l, m, n);
                                    }


                                }
                            }
                        }

                    }
                }
            }
            if (counter == 0)
            {
                Console.WriteLine("No");
            }
        }
    }
}
