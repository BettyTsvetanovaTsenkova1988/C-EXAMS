﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herbs
{
    class Program
    {
        static void Main(string[] args)
        {
            int expense = int.Parse(Console.ReadLine());
            string text = Console.ReadLine();
            int sumTotal = 0;
            int sum = 0;
            int mainCounter = 0;

            while (text != "Season Over")
            {
                string[] input = text.Split(' ');//!!!!!!!!!!
                int hours = Int32.Parse(input[0]);
                string obikalqi = input[1];// текста за обикаляне
                int price = Int32.Parse(input[2]);// цената на билките
                List<char> bukvi = new List<char> { };
                char[] rezano = new char[hours];
                int counter = 0;



                for (int i = 0; i < hours; i++)
                {
                    foreach (char c in obikalqi)
                    {
                        bukvi.Add(c);
                    }

                }
                // foreach (var item in bukvi)
                // {
                //  Console.WriteLine(item);
                //  }

                string result = string.Join("", bukvi.ToArray());//стринга в който ще броим

                for (int i = 0; i < hours; i++)
                {
                    rezano[i] = result[i];
                    if (rezano[i] == 'H')
                    {
                        counter++;
                    }

                }
                sum += (counter * price);
                
                //Console.WriteLine(result);

                // foreach (var item in rezano)
                //     {
                //  Console.WriteLine(rezano);
                //  }
                mainCounter++;
                text = Console.ReadLine();

            }
            decimal avg = (decimal)sum / (decimal)mainCounter;

            if (avg >= expense)
            {
                Console.WriteLine("Times are good. Extra money per day: {0:f2}.", avg - expense);
            }
            else
            {
                Console.WriteLine("We are in the red. Money needed: {0}.", Math.Abs(expense*mainCounter)-sum);
            }
        }
    }
}