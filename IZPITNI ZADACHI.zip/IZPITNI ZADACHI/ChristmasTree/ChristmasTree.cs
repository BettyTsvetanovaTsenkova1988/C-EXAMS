﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChristmasTree
{
    class ChristmasTree
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            char c = '^';
            
            Console.WriteLine("{0}{1}{0}",new string('\u0027',n),c);

            for (int i = 0; i < n/2; i++)
            {
                Console.WriteLine("{0}{1}{0}", new string('\u0027', n - 1 - i), new string(c, 3 + i + i));
            }

            for (int j = 0; j < (n + 1) / 2; j++)
            {
                Console.WriteLine("{0}{1}{0}", new string('\u0027', n - 1 - j), new string(c, 3 + j + j));
            }
           

            for (int k = 0; k < (n+1)/2; k++)
            {
                Console.WriteLine("{0}| |{0}", new string('\u0027', n - 1));
            }
            Console.WriteLine("{0}", new string('-', n * 2 + 1));
        }
    }
}
