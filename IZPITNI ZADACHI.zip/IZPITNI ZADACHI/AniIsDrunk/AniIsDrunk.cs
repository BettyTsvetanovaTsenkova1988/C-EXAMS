﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AniIsDrunk
{
    class AniIsDrunk
    {
        static void Main(string[] args)
        {
            long n = long.Parse(Console.ReadLine());
            string steps = Console.ReadLine();
            long currentPosition = 0;
            //long oldPosition = 0;
            //long difference = 0;
            long sumOfSteps = 0;

            while (steps != "Found a free one!")
            {
                long currentSteps = long.Parse(steps);
                long oldPosition = currentPosition;  // смята старата позиция
                currentPosition = (currentPosition + currentSteps) % n; // смята коя е текущата позиция
                long difference = currentPosition - oldPosition;

                

                if (difference < 0)
                {
                    Console.WriteLine("Go {0} steps to the left, Ani.", Math.Abs(difference));
                }
                else if (difference > 0)
                {
                    Console.WriteLine("Go {0} steps to the right, Ani.", Math.Abs(difference));
                }
                else
                {
                    Console.WriteLine("Stay there, Ani.");
                }
                sumOfSteps += Math.Abs(difference);

                steps = Console.ReadLine();//отново чете входа, за да не се върти цикъла безкрайно

            }
            Console.WriteLine("Moved a total of {0} steps.", sumOfSteps);
        }
    }
}
