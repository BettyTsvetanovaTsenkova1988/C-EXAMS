﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pairs
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = Console.ReadLine();
            string[] neshto = text.Split(' ');
            int[] input = new int[neshto.Length];

            int max = 0;
            int min = 0;
            int sum = 0;
            int check = Int32.MinValue;

            for (int i = 0; i < input.Length; i++)//пълни масива с елементите от началния стринг
            {
                input[i] = int.Parse(neshto[i]);
            }

            for (int j = 0; j < input.Length; j += 2)
            {               

              //  sum = input[j] + input[j + 1];
                int startSum = (input[0-j] + input[j-1]);
                int currentSum = (input[j] + input[j]);
               // if (sum > (input[j] + input[j + 1]))
              //  {
                 //   max = sum;
             //   }
                max = Math.Max(startSum, currentSum);
                min = Math.Min(startSum, currentSum);
                startSum = currentSum;          

            }

            if (max == min)
            {
                Console.WriteLine("Yes, value={0}", sum);
               
            }
            else
            {
                Console.WriteLine("No, maxdiff={0}", (max - min));
            }
        }
    }
}
