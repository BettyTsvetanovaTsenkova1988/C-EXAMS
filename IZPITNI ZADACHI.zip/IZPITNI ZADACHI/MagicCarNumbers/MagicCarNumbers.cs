﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagicCarNumbers
{
    class MagicCarNumbers
    {
        static void Main(string[] args)
        {
            int input = int.Parse(Console.ReadLine());            
            int counter = 0;
            int sum = 0;

            char[] letters = { 'A', 'B', 'C', 'E', 'H', 'K', 'M', 'P', 'T', 'X' };

            for (int i = 0; i <= 9; i++) //първо число
            {
                for (int j = 0; j <= 9; j++) //второ число
                {
                    for (int k = 0; k <= 9; k++) // трето число
                    {
                        for (int h = 0; h <= 9; h++) // четвърто число
                        {
                            for (int s = 0; s < letters.Length; s++)// първа буква
                            {
                                for (int z = 0; z < letters.Length; z++)//втора буква
                                {
                                    sum = 30 + 10 + i + j + k + h;

                                    if (letters[s] == 'A')
                                    {
                                        sum += 10;
                                    }
                                    else if (letters[s] == 'B')
                                    {
                                        sum += 20;
                                    }
                                    else if (letters[s] == 'C')
                                    {
                                        sum += 30;
                                    }
                                    else if (letters[s] == 'E')
                                    {
                                        sum += 50;
                                    }
                                    else if (letters[s] == 'H')
                                    {
                                        sum += 80;
                                    }
                                    else if (letters[s] == 'K')
                                    {
                                        sum += 110;
                                    }
                                    else if (letters[s] == 'M')
                                    {
                                        sum += 130;
                                    }
                                    else if (letters[s] == 'P')
                                    {
                                        sum += 160;
                                    }
                                    else if (letters[s] == 'T')
                                    {
                                        sum += 200;
                                    }
                                    else if (letters[s] == 'X')
                                    {
                                        sum += 240;
                                    }

                                    if (letters[z] == 'A')
                                    {
                                        sum += 10;
                                    }
                                    else if (letters[z] == 'B')
                                    {
                                        sum += 20;
                                    }
                                    else if (letters[z] == 'C')
                                    {
                                        sum += 30;
                                    }
                                    else if (letters[z] == 'E')
                                    {
                                        sum += 50;
                                    }
                                    else if (letters[z] == 'H')
                                    {
                                        sum += 80;
                                    }
                                    else if (letters[z] == 'K')
                                    {
                                        sum += 110;
                                    }
                                    else if (letters[z] == 'M')
                                    {
                                        sum += 130;
                                    }
                                    else if (letters[z] == 'P')
                                    {
                                        sum += 160;
                                    }
                                    else if (letters[z] == 'T')
                                    {
                                        sum += 200;
                                    }
                                    else if (letters[z] == 'X')
                                    {
                                        sum += 240;
                                    }


                                    if (input == sum)
                                    {


                                        if (i == j && j == k && k == h) // аааа
                                        {
                                            counter++;
                                        }
                                        else if (j == k && k == h && i != j) // abbb
                                        {
                                            counter++;
                                        }
                                        else if (i == j && j == k && h != i)//aaab
                                        {
                                            counter++;
                                        }
                                        else if (i == j && k == h && i != h) //aabb
                                        {
                                            counter++;
                                        }

                                        else if (i == h && j == k && i != j)//abba
                                        {
                                            counter++;
                                        }
                                        else if (i == k && j == h && i != j)//abab
                                        {
                                            counter++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Console.WriteLine(counter);
        }
    }
}

