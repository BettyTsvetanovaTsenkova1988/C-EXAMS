﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneProcesess2
{
    class PhoneProcesess2
    {
        static void Main(string[] args)
        {
            string power = Console.ReadLine().Trim();
            int powerNew = int.Parse(power.Substring(0,power.Length-1)); //маха последния знак

            

            string input = Console.ReadLine().Trim();
            List<string> allStrings = new List<string> { };
            

            while (input.ToLower() != "end")
            {             

                allStrings.Add(input);
                input = Console.ReadLine().Trim();
                
            }

            if (powerNew == 0)
            {
                Console.WriteLine("Phone Off");
            }
            else if (powerNew<=15 && powerNew>0)
            {
               Console.WriteLine("Connect charger -> {0}%",powerNew);
               Console.WriteLine("Programs left -> {0}", allStrings.Count);
            }

            else
            {
                for (int i = 0; i < allStrings.Count; i++)
                {
                    string current = allStrings[i];
                    string[] arr = current.Split(new char[] { '_', '%' }, StringSplitOptions.RemoveEmptyEntries);

                    powerNew -= int.Parse(arr[1]); // парсваме елемента на дадения индекс и вадим заряда

                    if (powerNew <= 15 && powerNew > 0)
                    {
                        Console.WriteLine("Connect charger -> {0}%", powerNew);
                        Console.WriteLine("Programs left -> {0}", allStrings.Count - 1 - i);
                        break;
                    }

                    else if (powerNew <= 0)
                    {
                        Console.WriteLine("Phone Off");
                        break;
                    }



                }
            }

            
            if (powerNew > 15 )
            {
                Console.WriteLine("Successful complete -> {0}%",powerNew);
            }
        }
    }
}
