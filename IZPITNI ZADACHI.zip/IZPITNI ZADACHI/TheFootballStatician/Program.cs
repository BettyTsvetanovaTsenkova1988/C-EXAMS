﻿using System;

class Program
{
    static void Main()
    {
        decimal price = decimal.Parse(Console.ReadLine());
        string user = Console.ReadLine();
        while (user != "End of the league.");

        string[] teams = { null,"Arsenal", "Chelsea", "ManchesterCity", "ManchesterUnited", "Liverpool", "Everton", "Southampton", "Tottenham" };
        string[] outcome = {null, "1", "X", "2" };
        string result = string.Empty;
        string outnew = string.Empty;
        for (int i = 0; i < teams.Length; i++)
        {
           result= teams[i]+ outnew[i] + teams[i];
        }

        Console.WriteLine(result);
    }
}

