﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cake
{
    class Program
    {
        static void Main(string[] args)
        {
            long n = long.Parse(Console.ReadLine());//123
            decimal c = decimal.Parse(Console.ReadLine());//kg floor needed for 1 cake//1.2
            long f = long.Parse(Console.ReadLine());//available floor//150
            long t = long.Parse(Console.ReadLine());//available truffles //15
            decimal p = decimal.Parse(Console.ReadLine());//price for1 truff//2000

            decimal canMadecakes = (decimal)f / c;//може да направи
            decimal trufflePrice = t * p;
            decimal priceForPeace = trufflePrice/n;
            decimal cakePrice = priceForPeace + (priceForPeace * 0.25m);
           



            if (canMadecakes >= n)
            {
                Console.WriteLine("All products available, price of a cake: {0:F2}",cakePrice);
            }
            else if (canMadecakes < n)
            {
                 canMadecakes = (decimal)f / c;//може да направи
                 trufflePrice = t * p;
                 priceForPeace = trufflePrice / canMadecakes;
                 cakePrice = priceForPeace + (priceForPeace * 0.25m);
                 decimal neededTotal = n * c;
                 decimal diff = neededTotal - f;
                 Console.WriteLine("Can make only {0} cakes, need {1:f2} kg more flour",Math.Floor(canMadecakes),diff);
            }
            
        }
    }
}
