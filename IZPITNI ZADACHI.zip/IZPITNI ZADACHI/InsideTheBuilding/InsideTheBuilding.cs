﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsideTheBuilding
{
    class InsideTheBuilding
    {
        static void Main(string[] args)
        {
            int hIndex = int.Parse(Console.ReadLine());
            int x1 = int.Parse(Console.ReadLine());
            int y1 = int.Parse(Console.ReadLine());
            int x2 = int.Parse(Console.ReadLine());
            int y2 = int.Parse(Console.ReadLine());
            int x3 = int.Parse(Console.ReadLine());
            int y3 = int.Parse(Console.ReadLine());
            int x4 = int.Parse(Console.ReadLine());
            int y4 = int.Parse(Console.ReadLine());
            int x5 = int.Parse(Console.ReadLine());
            int y5 = int.Parse(Console.ReadLine());

            Calculation(hIndex, x1, y1);
            Calculation(hIndex, x2, y2);
            Calculation(hIndex, x3, y3);
            Calculation(hIndex, x4, y4);
            Calculation(hIndex, x5, y5);     
                       

        }

        static bool Calculation(int h, int x, int y)
        {
            bool inside = false;
            
            if (x >= 0 && x <= h * 3 && y>= 0 && y <= h) // за долната част
            {
                Console.WriteLine("inside");
                inside = true;
                return inside;
            }
            else if (x >= h && x <= h * 2 && y >= 0 && y <= h * 4)
            {
                Console.WriteLine("inside");
                inside = true;
                return inside;
            }
            else
            {
                Console.WriteLine("outside");
                inside = false;
                return inside;
            }


        }
    }
}
