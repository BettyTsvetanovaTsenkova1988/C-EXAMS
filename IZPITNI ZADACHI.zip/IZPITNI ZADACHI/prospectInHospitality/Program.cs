﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        uint numB = uint.Parse(Console.ReadLine());
        uint numR = uint.Parse(Console.ReadLine());
        uint numC = uint.Parse(Console.ReadLine());
        uint numT = uint.Parse(Console.ReadLine());
        uint numO = uint.Parse(Console.ReadLine());
        decimal numN = decimal.Parse(Console.ReadLine());
        decimal numU = decimal.Parse(Console.ReadLine());
        decimal numS = decimal.Parse(Console.ReadLine());
        decimal numM = decimal.Parse(Console.ReadLine());
        decimal builders = 1500.04m;
        decimal receptionist = 2102.10m;
        decimal chambermaids = 1465.46m;
        decimal technicians = 2053.33m;
        decimal others = 3010.98m;

        decimal tBuilders = numB * builders;
        decimal tReceptionist = numR * receptionist;
        decimal tChambermaids = numC * chambermaids;
        decimal tTechnicals = numT * technicians;
        decimal tOthers = (numO * others) + (numN * numU) + numS;
        decimal all = (tBuilders + tReceptionist + tChambermaids + tTechnicals + tOthers);

        Console.WriteLine("The amount is: {0:F2} lv.", all);
        decimal left = numM - all;

        if (numM >= all)
        {
            Console.WriteLine(@"YES \ Left: {0:f2} lv.", left);
        }

        else
        {
            if (left < 0)
            {
                left = -left;
                
            }
            Console.WriteLine(@"NO \ Need more: {0:f2} lv.", left);
        }

    }
}

