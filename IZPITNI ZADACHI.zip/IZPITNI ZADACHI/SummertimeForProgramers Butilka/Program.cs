﻿using System;

class Butilka
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int space = n / 2;
        int top = n + 1;
        int bottom = 2 * n;
        int height = 3 * n + 1;
        
        Console.WriteLine("{0}{1}",new string(' ',space),new string('*',top));
        for (int i = 0; i <= n/2; i++)
        {
            Console.WriteLine("{0}{1}{2}{3}", new string(' ', space), new string('*', 1), new string(' ', n - 1), new string('*', 1));
        }
        for (int j = 0; j < n/2-1; j++)
        {
            Console.WriteLine("{0}{1}{2}{1}",new string(' ',n/2-1-j),new string('*',1),new string(' ', n+1+2*j),new string('*',1));            
        }
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("*{0}*",new string('.',n*2-2));
        }
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("*{0}*", new string('@', n * 2 - 2));
        }
        Console.WriteLine("{0}",new string('*',bottom));

    }
}

