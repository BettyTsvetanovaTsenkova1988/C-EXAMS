﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FourFactor
{
    class Program
    {
        static void Main(string[] args)
        {
            long fg = long.Parse(Console.ReadLine());
            long fga = long.Parse(Console.ReadLine());
            long threep = long.Parse(Console.ReadLine());
            long tov = long.Parse(Console.ReadLine());
            long orb = long.Parse(Console.ReadLine());
            long oppdrb = long.Parse(Console.ReadLine());
            long ft = long.Parse(Console.ReadLine());
            long fta = long.Parse(Console.ReadLine());

            double EFG = ((fg + 0.5 * threep) / fga);
            double TOV = (tov / (fga + 0.44 * fta + tov));
            double ORB = (double)orb / (orb + oppdrb);
            double FT = (double)ft / fga;

            if (EFG >= 0 && TOV >= 0 && ORB >= 0 && FT >= 0)
            {
                Console.WriteLine("eFG% {0:F3}", EFG);
                Console.WriteLine("TOV% {0:F3}", TOV);
                Console.WriteLine("ORB% {0:F3}", ORB);
                Console.WriteLine("FT% {0:F3}", FT);
            }

        }
    }
}
