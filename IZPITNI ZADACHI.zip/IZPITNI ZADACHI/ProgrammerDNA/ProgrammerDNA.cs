﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammerDNA
{
    class ProgrammerDNA
    {
        static void Main(string[] args)
        {
            int start = int.Parse(Console.ReadLine());
            char input = char.Parse(Console.ReadLine());

            for (int i = 0; i < start/7; i++)
            {
                Console.WriteLine("...{0}...",new string(input,1));
                Console.WriteLine("..{0}{1}{2}..",new string(input+1,1));
            }
        }
    }
}
