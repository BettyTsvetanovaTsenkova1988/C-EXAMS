﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelerBob
{
    class TravelerBob
    {
        static void Main(string[] args)
        {
            string year = Console.ReadLine();
            int c = int.Parse(Console.ReadLine());
            int f = int.Parse(Console.ReadLine());
            int contractMonth = 0;
            int familyMonth = 0;
            int diffMonts = 12 - c - f;
            int normal = 0;
            double total = 0;
            double allTravelled = 0;

            if (year == "leap")
            {
                 contractMonth = 4 * 3 * c; //пътувания за работен месец
                 familyMonth = 2 * 2 * f; // пътувания в семеен месец
                 normal = diffMonts * 12; // 12 пътувания в работен месец 4седм * 3 пътувания на седмица
                total = (double)normal * (double)(0.6);
                 allTravelled = contractMonth + familyMonth + total;
                double additional = allTravelled + (allTravelled * 0.05d);
                Console.WriteLine("{0}", Math.Floor(additional));
            }
            else
            {
                contractMonth = 4 * 3 * c; //пътувания за работен месец
                familyMonth = 2 * 2 * f; // пътувания в семеен месец
                normal = diffMonts * 12; // 12 пътувания в работен месец 4седм * 3 пътувания на седмица
                total = (double)normal * (double)(0.6);
                allTravelled = contractMonth + familyMonth + total;
               
                Console.WriteLine("{0}", Math.Floor(allTravelled));
            }
            
        }
    }
}
