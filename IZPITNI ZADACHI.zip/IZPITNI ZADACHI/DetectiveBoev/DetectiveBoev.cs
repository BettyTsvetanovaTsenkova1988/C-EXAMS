﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DetectiveBoev
{
    class DetectiveBoev
    {
        static void Main(string[] args)
        {
            string word = Console.ReadLine();
            string dumi = Console.ReadLine();
            int sum = 0;
         
            List<string> neshto = new List<string>{};

            for (int i = 0; i < word.Length; i++)
            {
                sum += word[i];
            }

            string text = sum.ToString();

            int devider = 0;

            for (int i = 0; i < text.Length; i++)
            {
                while (sum > 9)
                {
                    devider += (int)char.GetNumericValue(text[i]); //директно сумира числата а не чаровете
                }
            }

            
            for (int i = 0; i < dumi.Length; i++) // сумира или вади маската от текущия чар
            {
                if (dumi[i] % devider == 0)
                {

                  char  totaldumite = (char)(dumi[i] + devider);
                    neshto.Add(totaldumite.ToString());
                   
                }
                else
                {
                   char totaldumite = (char)(dumi[i] - devider);
                    neshto.Add(totaldumite.ToString());
                   
                }

            }

            neshto.Reverse();
            Console.WriteLine(string.Join("",neshto));
        }
    }
}
