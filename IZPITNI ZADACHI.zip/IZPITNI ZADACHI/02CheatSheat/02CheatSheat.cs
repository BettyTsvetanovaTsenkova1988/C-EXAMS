﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02CheatSheat
{
    class Program
    {
        static void Main(string[] args)
        {
            long r = long.Parse(Console.ReadLine());
            long c = long.Parse(Console.ReadLine());
            long one = long.Parse(Console.ReadLine());
            long two = long.Parse(Console.ReadLine());

            for ( long i = 0; i < r; i++)
            {
                for (long j = 0; j < c; j++)
                {
                    Console.Write((one+ i)*(two + j) + " ");
                }
                Console.WriteLine();
            }
           
        }
    }
}
