﻿using System;

class Disk
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int r = int.Parse(Console.ReadLine());
        int diskCenterRow = n / 2,
            diskCenterCol = n / 2;

        for (int Row = 0; Row < n; Row++)
        {
            for (int Col = 0; Col < n; Col++)
            {
                int x = Col - diskCenterCol,//от номера на колоната се вади n/2
                    y = Row - diskCenterRow;//от номера на реда се вади n/2
                double distanceToCenter = Math.Sqrt(x * x + y * y); 
                bool isWithinDisk = distanceToCenter <= r; 

                if (isWithinDisk)
                {
                    Console.Write('*');
                }
                else
                {
                    Console.Write('.');
                }
            }
            Console.WriteLine();
        }
    }
}

