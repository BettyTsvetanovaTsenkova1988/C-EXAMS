﻿using System;

class TakeThePlaneDown
{
    static void Main()
    {
        int x = int.Parse(Console.ReadLine());
        int y = int.Parse(Console.ReadLine());
        int radius = int.Parse(Console.ReadLine());
        int numberPlanes = int.Parse(Console.ReadLine());
        
        for (int i = 0; i < numberPlanes; i++)
        {
           int pX = int.Parse(Console.ReadLine());
           int pY = int.Parse(Console.ReadLine());

           if (Math.Abs(x-pX)<= radius && (Math.Abs(y-pY)<=radius ))
           {
               Console.WriteLine("You destroyed a plane at [{0},{1}]",pX,pY);
           }
           
        }


    }
}
