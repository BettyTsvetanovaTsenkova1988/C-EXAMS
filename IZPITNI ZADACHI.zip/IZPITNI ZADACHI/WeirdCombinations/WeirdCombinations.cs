﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeirdCombinations
{
    class WeirdCombinations
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int possition = int.Parse(Console.ReadLine());
            int counter = 0;
            string combination = null;

            for (int a = 0; a < input.Length; a++)
            {
                for (int b = 0; b < input.Length; b++)
                {
                    for (int c = 0; c < input.Length; c++)
                    {
                        for (int d = 0; d < input.Length; d++)
                        {
                            for (int e = 0; e < input.Length; e++)
                            {
                                counter++;
                                combination = input[a] + "" + input[b] + "" + input[c] + "" + input[d] + "" + input[e];
                                if ((possition) == counter - 1)//така е зададено по условие да се започва от 0!!!
                                {
                                    Console.WriteLine(combination);
                                }
                                //Console.WriteLine(combination);

                            }
                        }
                    }
                }
            }
            if (possition >= counter)
            {
                Console.WriteLine("No");
            }

        }
    }
}
