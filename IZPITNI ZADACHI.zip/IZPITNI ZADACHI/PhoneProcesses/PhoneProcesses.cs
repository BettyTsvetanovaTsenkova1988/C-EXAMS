﻿using System;

namespace PhoneProcesses
{
    class Program
    {
        static void Main()
        {
            int batteryPercentage = int.Parse(Console.ReadLine().Replace("%", ""));//чете входа и замества % с нищо
            int remainingApps = 0;

            while (true) 
            {
                string application = Console.ReadLine();// чете стинга с приложението от конзолата
                if (application.ToLower() == "end") break;

                if (batteryPercentage > 15)
                {
                    string[] appDetails = application.Split('_');// от входа се прави масив сплитнат по _ черта
                    int currApp = int.Parse(appDetails[1].Replace("%", "")); //от елемента на позициа 1 се маха % и остават само цифрите
                    batteryPercentage -= currApp;
                }
                else
                {
                    remainingApps++;
                }
            }

            if (batteryPercentage <= 0)
            {
                Console.WriteLine("Phone Off");
            }
            else if (batteryPercentage <= 15)
            {

                Console.WriteLine(
                    "Connect charger -> {0}%{2}Programs left -> {1}",
                    batteryPercentage,
                    remainingApps,
                    Environment.NewLine);
            }
            else
            {
                Console.WriteLine("Successful complete -> {0}%", batteryPercentage);
            }
        }
    }
}