﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlaidTowel
{
    class PlaidTowel
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            char b = char.Parse(Console.ReadLine());
            char sym = char.Parse(Console.ReadLine());

            Console.WriteLine("{0}{1}{2}{1}{0}", new string(b, n), new string(sym, 1), new string(b, n * 2 - 1));// ПЪРВИ РЕД

            for (int i = 0; i < n - 1; i++)
            {

                Console.WriteLine("{0}{1}{2}{1}{3}{1}{2}{1}{0}", new string(b, n - 1 - i), sym, new string(b, 1 + i + i), new string(b, n * 2 - 3 - i * 2));
            }
            Console.WriteLine("{0}{1}{0}{1}{0}",sym, new string(b,n*2-1));

            for (int i = 0; i < n-1; i++)
            {
                Console.WriteLine("{0}{1}{2}{1}{3}{1}{2}{1}{0}", new string(b, 1+i), sym, new string(b, n * 2 - 3 - i * 2), new string(b, 1 + i * 2));
            }
            Console.WriteLine("{0}{1}{2}{1}{0}", new string(b, n), new string(sym, 1), new string(b, n * 2 - 1));
            for (int i = 0; i < n - 1; i++)
            {

                Console.WriteLine("{0}{1}{2}{1}{3}{1}{2}{1}{0}", new string(b, n - 1 - i), sym, new string(b, 1 + i + i), new string(b, n * 2 - 3 - i * 2));
            }
            Console.WriteLine("{0}{1}{0}{1}{0}", sym, new string(b, n * 2 - 1));

            for (int i = 0; i < n - 1; i++)
            {
                Console.WriteLine("{0}{1}{2}{1}{3}{1}{2}{1}{0}", new string(b, 1 + i), sym, new string(b, n * 2 - 3 - i * 2), new string(b, 1 + i * 2));
            }
            Console.WriteLine("{0}{1}{2}{1}{0}", new string(b, n), new string(sym, 1), new string(b, n * 2 - 1));
        }
    }
}
