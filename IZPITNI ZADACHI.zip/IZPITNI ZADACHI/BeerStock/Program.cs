﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeerStock
{
    class Program
    {
        static void Main(string[] args)
        {
            int reserved = int.Parse(Console.ReadLine());
            string input = Console.ReadLine();

            long delivered = long.Parse(input.Substring(0, 1));
            long beerSum = 0;
            string word = (input.Substring(1, input.Length - 1));

            while (input != "Exam Over")
            {
                string[] text = input.Split(' ');
                delivered = Int32.Parse(text[0]);
                word = (text[1]);

                if (word == "beers")
                {
                    delivered = delivered;
                }
                else if (word == "sixpacks")
                {
                    delivered = delivered * 6;
                }
                else if (word == "cases")
                {
                    delivered = delivered * 24;
                }
                beerSum += delivered;

                //  switch (word)
                //  {
                // case "beers": beerSum += delivered; break;
                //  case "sixpacks": beerSum += (6 * delivered); break;
                //  case "cases": beerSum += (24 * delivered); break;
                //  default:
                //   break;
                input = Console.ReadLine();
            }
            if (beerSum >= reserved )
            {
                beerSum = beerSum - (beerSum / 100);
                long diff = reserved - beerSum;
                long casesneeded = diff / 24L;//колко каси
                long remcasesneeded = diff % 24L;//остатък
                long beersNeeded = remcasesneeded / 6L;
                long rembeers = remcasesneeded % 6L;
                Console.WriteLine("Cheers! Beer left: {0} cases, {1} sixpacks and {2} beers.", Math.Abs(casesneeded), Math.Abs(beersNeeded), Math.Abs(rembeers));
            }
           
            
            else 
            {
                beerSum = beerSum - (beerSum / 100);
                long diff = reserved - beerSum;
                long casesneeded = diff / 24L;//колко каси
                long remcasesneeded = diff % 24L;//остатък
                long beersNeeded = remcasesneeded / 6L;
                long rembeers = remcasesneeded % 6L;
                Console.WriteLine("Not enough beer. Beer needed: {0} cases, {1} sixpacks and {2} beers.", Math.Abs(casesneeded), Math.Abs(beersNeeded), Math.Abs(rembeers));
            }
           
            }
        }

    }
