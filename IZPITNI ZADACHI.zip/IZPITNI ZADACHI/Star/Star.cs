﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Star
{
    class Star
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("{0}*{0}",new string('.',n)); // първи статичен

            for (int i = 0; i < (n/2)-1; i++)
            {
                Console.WriteLine("{0}*{1}*{0}",new string('.',n-1-i),new string('.',1+2*i));
            }

            Console.WriteLine("{0}{1}{0}",new string('*',(n/2)+1),new string('.',n-1)); //статичен ред

            for (int j = 0; j < (n/2)-1; j++)//жълто
            {
                Console.WriteLine("{0}*{1}*{0}",new string('.',1+j),new string('.',(n*2)-3-2*j));
            }

            Console.WriteLine("{0}*{1}*{1}*{0}",new string('.',n/2),new string('.',(n/2)-1));// червено

            for (int k = 0; k < (n/2)-1; k++)
            {
                Console.WriteLine("{0}*{1}*{2}*{1}*{0}",new string('.',(n/2)-1-k),new string('.',(n/2)-1),new string('.',1+2*k));
            }
            Console.WriteLine("{0}{1}{0}", new string('*', (n / 2) + 1), new string('.', n - 1));
        }
    }
}
