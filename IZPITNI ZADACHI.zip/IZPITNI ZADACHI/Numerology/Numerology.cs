﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Numerology
{
    class Numerology
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] arr = input.Split(' ', '.');
            long date = Convert.ToInt64(arr[0]) * Convert.ToInt64(arr[1]) * Convert.ToInt64(arr[2]); //умножава рожденната дата

            if (Convert.ToInt64(arr[1]) % 2 != 0) //ПРОВЕРЯВА месеца дали е нечетен и умножава по 2
            {
                date *= date;
            }
            long result = 0 + date;
            char[] name = arr[3].ToCharArray(); //обръща името на масив от чарове
            for (int i = 0; i < name.Length; i++)
            {
                char currentChar = name[i];

                if (currentChar >= '0' && currentChar <= '9')
                {
                    result += currentChar - '0';
                }
                else if (currentChar >= 'a' && currentChar <= 'z')
                {
                    result += currentChar - 'a' + 1;
                }
                else if (currentChar >= 'A' && currentChar <= 'Z')
                {
                    result += 2 * (currentChar - 'A' + 1);
                }
            }
          //  string result = sumName.ToString();//обръща сумата към стринг, за да се съберат числата

            while (result > 13)
            {
                int digitSum = 0;

                while (result > 0)
                {
                    digitSum += (int)(result % 10);//разделя крайното число % на 10 и събира САМО остатъците
                    result /= 10; //дели на 10, за да се махне последната цифра от числото и отново се завърта цикъла
                }

                result = digitSum;
            }

            Console.WriteLine(result);

        }

    }
}

