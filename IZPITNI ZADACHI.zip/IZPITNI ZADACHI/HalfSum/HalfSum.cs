﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HalfSum
{
    class HalfSum
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
           
            int numberOne = 0;
            int numberTwo = 0;
            int sumOne = 0;
            int sumTwo = 0;

            for (int i = 0; i < n; i++)//чете и събира първата редица от числа
            {
                 numberOne = int.Parse(Console.ReadLine());
              
                 sumOne += numberOne;
            }
            for (int j = 0; j < n; j++)//чете и събира втората редица от числа
            {
                numberTwo = int.Parse(Console.ReadLine());
               
                sumTwo += numberTwo;
            }

            if (sumOne==sumTwo)
            {
                Console.WriteLine("Yes, sum={0}",sumOne);
            }
            else 
            {
                Console.WriteLine("No, diff={0}",Math.Abs(sumOne-sumTwo));
            }

        }
    }
}
