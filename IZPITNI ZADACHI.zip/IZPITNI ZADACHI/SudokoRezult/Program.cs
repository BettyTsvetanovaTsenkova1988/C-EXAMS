﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SudokoRezult
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int countGames = 0;
            int sec = 0;
            while (input != "Quit")
            {
                countGames++;
                int min = int.Parse(input.Substring(0, 2));
                sec += int.Parse(input.Substring(3, 2));
                sec += min * 60;
                input = Console.ReadLine();
            }

            double avg = Math.Ceiling((double)sec / countGames);
            if (avg < 720)
            {
                Console.WriteLine("Gold Star");
            }
            else if (avg <= 1440 && avg >= 720)
            {
                Console.WriteLine("Silver Star");
            }
            else if (avg > 1440)
            {
                Console.WriteLine("Bronze Star");
            }
            Console.WriteLine("Games - {0} \\ Average seconds - {1}",countGames,avg);
        }
    }
}
