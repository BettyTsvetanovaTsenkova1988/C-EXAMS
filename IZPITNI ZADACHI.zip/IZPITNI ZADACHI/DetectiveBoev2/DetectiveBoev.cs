﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DetectiveBoev2
{
    class DetectiveBoev
    {
        static void Main(string[] args)
        {
            string secretWord = Console.ReadLine();
            string message = Console.ReadLine();
            int mask = 0;

            foreach (char c in secretWord)//обикаля ключовата дума от входа и сумира чаровете, за да се получи числото на маската
            {
                mask += (int)c;
            }     
            
            while (mask > 9)// обикаля маската, докато тя е по-голяма от 9, ако стане по-малка не прави нищо
            {
                string maskString = mask.ToString();//обръща числото от маската на стринг
                mask = 0; // ако маската е двуцифрено число/по-голяма е от 9/, сумата на числата от маската се занулява, за да може новото число да се сумира, докато не стане едноцифрено число /пример: маската е първоначално 102 и е >9, зануляваме я и сумираме наново 1+0+2 и така докато числото на маската не стане едноцифрено..

                foreach (char k in maskString)
                {
                    mask +=(int)char.GetNumericValue(k);//взема стойността от аскито на дадения чар и сумира тази стойност
                   
                }

            }

            string messageDecripted = "";//създава се празен стринг, където да се запази новото съобщение за печатане на конзолата
          
            for (int i = message.Length - 1; i >= 0; i--)//обикаля думата за съобщението за дешифриране и проверява дали се дели на четно или не, по условие се иска да се ревърсне и затова цикъла е на обратно
            {
                if (message[i] % mask == 0)
                {
                    messageDecripted += (char)(message[i] + mask); //ако да, чарът се сумира с маската
                }

                else 
                {
                    messageDecripted += (char)(message[i] - mask);//ако не - маската се вади от чара
                }

            }


           
           Console.WriteLine(messageDecripted);
        }
    }
}
