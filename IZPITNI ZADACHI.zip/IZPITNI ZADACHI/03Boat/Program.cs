﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03Boat
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i <(n-1)/2; i++)
            {
                Console.WriteLine("{0}{1}{2}",new string('.',(n-1-i-i)),new string('*',(1+i+i)),new string('.',n));
            }

            Console.WriteLine("{0}{1}",new string('*',n), new string ('.',n));

            for (int j = 0; j < (n/2)-1; j++)
            {
                Console.WriteLine("{0}{1}{2}", new string('.', 2 + j + j), new string('*',n-2 - j- j),new string('.',n));
            }
            Console.WriteLine("{0}{1}{2}",new string('.',n-1),new string('*',1),new string('.',n));

            for (int k = 0; k < (n-1)/2; k++)
            {
                Console.WriteLine("{0}{1}{0}",new string('.',0+k),new string('*',(n*2)-k-k));
            }
        }
    }
}
