﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace waveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            long number = long.Parse(Console.ReadLine());

            string n = Convert.ToString(number, 2).PadLeft(32, '0');
            string current = null;
            string maximum = null;
            List<string> curr = new List<string> { };
            List<string> maximal = new List<string> { };


            for (int i = 0; i < 30; i+=2)
            {
                for (int j = 1; j < 29; j+=2)
                {
                    for (int k = 2; k < 28; k+=2)
                    {
                        if (i+j+k < 31)
                        {
                            current = n[i + j + k + 0].ToString() + n[i + j + k + 1].ToString() + (n[2 + i + j + k]);
                            if (current == "101")
                            {
                                int c = Convert.ToInt32(current);
                                int m = Convert.ToInt32(maximum);
                                curr.Add(current);

                                if (curr.Count>maximal.Count)
                                {
                                    maximal = curr;
                                }
                                
                            }
                        }
                       
                    }
                }
               
              
            }
           
            if (current!= "101")//вярно!!!
            {
                Console.WriteLine("No waves found!");
            }
        }
    }
}
