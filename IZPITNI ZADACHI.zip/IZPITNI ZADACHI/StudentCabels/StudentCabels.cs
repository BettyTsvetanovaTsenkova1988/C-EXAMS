﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentCabels
{
    class StudentCabels
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int inputCables = n;

            int lenghtInput = 0;
            string measure = null;
            int sumInput = 0;
            int all = 0; //пази тотала
            double rezult = 0;
            double reminder = 0;


            for (int i = 0; i < inputCables; i++)
            {
                lenghtInput = int.Parse(Console.ReadLine());//дължината на кабела от входа
                measure = Console.ReadLine(); //мерната единица   

                switch (measure)
                {
                    case "meters": lenghtInput = lenghtInput * 100; break;
                    case "centimeters": lenghtInput = lenghtInput; break;
                    default: break;
                }


                if (lenghtInput >= 20)
                {
                    sumInput += lenghtInput;
                }
                else if (lenghtInput < 20)
                {
                    lenghtInput = 0;
                    sumInput += lenghtInput;
                    n--;
                }
                
               

            }

            all = (sumInput - ((n - 1) * 3)); //общо кабели без парчетата за свързване
            rezult = all / 504; // смята колко ще са студентските кабели 1-ви ред от аута
            reminder = all - (rezult * 504);


            Console.WriteLine("{0}", rezult);
            Console.WriteLine("{0}", reminder);

        }
    }
}
