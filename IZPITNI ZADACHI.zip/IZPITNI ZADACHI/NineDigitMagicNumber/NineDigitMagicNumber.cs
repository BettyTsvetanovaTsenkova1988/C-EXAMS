﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NineDigitMagicNumber
{
    class NineDigitMagicNumber//недовършена!!!
    {
        static void Main(string[] args)
        {
            int sum = int.Parse(Console.ReadLine());
            int diff = int.Parse(Console.ReadLine());
            int total = 0;
            int two = 0;
            int three = 0;

            for (int one = 111; one <= 777; one++)
            {
                two = one + diff;
                three = two + diff;
                string first = one.ToString();
                string second = two.ToString();
                string fird = three.ToString();
              
                    first =(first[0] + first[1] + first[2]).ToString();
                    second = (second[0] + second[1] + second[2]).ToString();
                    fird = (fird[0] + fird[1] + fird[2]).ToString();

              
               total = int.Parse(first+second+fird);

                if (sum == total)
                {

                    if (diff == three - two && diff == three - one)
                    {
                        Console.Write(one);//печата първо първата тройка
                        Console.Write(two); // втора тройка
                        Console.Write(three);//последна трета тройка
                        Console.WriteLine();

                    }
                }
            }
        }
    }
}

