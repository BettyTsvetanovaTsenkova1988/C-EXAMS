﻿using System;

class DailyCalorieInTake
{
    static void Main()
    {
        int w = int.Parse(Console.ReadLine());
        int h = int.Parse(Console.ReadLine());
        int a = int.Parse(Console.ReadLine());
        char gender = char.Parse(Console.ReadLine());
        int e = int.Parse(Console.ReadLine());
       
      
        double wkg = w / 2.2d;
        double hsm = h * 2.54d;
        double bMRmen = 66.5d + (13.75d * wkg) + (5.003d * hsm) - (6.755d * a);
        double bMRwoman = 655 + (9.563d * wkg) + (1.850d * hsm) - (4.676 * a);
        double dCI = 0;
        double workoursIndex = 0;

        if (e <= 0)
        {
            workoursIndex = 1.2d;
        }
        else if (e >= 1 && e <= 3)
        {
            workoursIndex = 1.375d;
        }
        else if (e >= 4 && e <= 6)
        {
            workoursIndex = 1.55d;
        }
        else if (e >= 7 && e <= 9)
        {
            workoursIndex = 1.725d;
        }
        else if (e > 10)
        {
            workoursIndex = 1.9d;
        }
        
        if (gender == 'm')
        {
            dCI = bMRmen * workoursIndex;
            Console.WriteLine(Math.Floor(dCI));
        }
        else if (gender == 'f')
        {
            dCI = bMRwoman * workoursIndex;
            Console.WriteLine(Math.Floor(dCI));
        }        
    }
}

