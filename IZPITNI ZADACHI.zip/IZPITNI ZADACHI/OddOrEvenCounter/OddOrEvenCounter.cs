﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class OddOrEvenCounter
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int c = int.Parse(Console.ReadLine());
        string textInput = Console.ReadLine();

        int odd = 0;
        int even = 0;
        int tempOdd = 0;
        int tempEven = 0;
        string nameOdd = null;
        string nameEven = null;
       

       string[] nameWinner =  { "First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eighth", "Ninth", "Tenth" };

        for (int i = 0; i < n; i++)//върти цикъла колкото масиви с числа ще има
        {
            tempEven = 0;//при всяка нова итерация занулява стойността
            tempOdd = 0;//при всяка нова итерация занулява стойността
            for (int j = 0; j < c; j++) //върти с на брой пъти колкото са числата в самия масив
            {

                int number = int.Parse(Console.ReadLine());
               
                if (number % 2 == 0)//проверка четно
                {
                    tempEven++;
                    if (tempEven > even)
                    {
                        even = tempEven;
                        nameEven = nameWinner[i];
                    }
                }
                else //проверка нечетно
                {
                    tempOdd++;
                    if (tempOdd > odd)
                    {
                        odd = tempOdd;
                        nameOdd = nameWinner[i];
                    }
                }
            }
        }
        if (even == 0 || odd == 0)
        {
            Console.WriteLine("No");
        }
        else if (textInput == "odd")
        {
            Console.WriteLine("{0} set has the most odd numbers: {1}", nameOdd, odd);
        }
        else if (textInput == "even")
        {
            Console.WriteLine("{0} set has the most even numbers: {1}", nameEven, even);
        }

    }
}