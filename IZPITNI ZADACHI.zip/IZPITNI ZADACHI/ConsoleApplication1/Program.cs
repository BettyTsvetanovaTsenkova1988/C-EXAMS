﻿using System;

class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int[] numbers = new int[n];

        for (int i = 0; i < numbers.Length; i++)
        {
            numbers[i] = int.Parse(Console.ReadLine());
        }

        Array.Sort(numbers);
        if (numbers.Length<3)
        {
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.WriteLine(numbers[i]); 
            } 
        }
        else
        {
            for (int i = 0; i < 3; i++)
            {
                 Console.WriteLine(numbers[i]); 
            }
        }
    }
}
