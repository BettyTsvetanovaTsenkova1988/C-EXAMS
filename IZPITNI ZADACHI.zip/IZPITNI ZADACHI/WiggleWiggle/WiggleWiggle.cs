﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WiggleWiggle
{
    class WiggleWiggle
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split();
            for (int i = 0; i < input.Length; i += 2)
            {
                long n1 = long.Parse(input[i]);
                long n2 = long.Parse(input[i + 1]);

                for (int j = 0; j < 63; j += 2)//до 63 по условие, обикаля ч„ислото 
                {
                    long currBit1 = (n1 >> j) & 1L;//мести числото даден брой пъти
                    long currBit2 = (n1 >> j) & 1L;

                    if (currBit1 != currBit2)
                    {
                        if (currBit1 == 1)
                        {
                            n1 ^= 1 << j;
                            n2 |= currBit1 << j;
                        }
                        else
                        {
                            n2 ^= 1L << j;
                            n1 |= currBit2 << j;
                        }
                    }



                }
                n1 = n1 ^long.MaxValue;
                n2 = n2 ^ long.MaxValue;

                string n1Bin = Convert.ToString(n1, 2).PadLeft(63,'0');
                string n2Bin = Convert.ToString(n2, 2).PadLeft(63, '0');

                Console.WriteLine("{0} {1}",n1,n1Bin);
                Console.WriteLine("{0} {1}", n2, n2Bin);


            }

        }
    }
}
