﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01PiggyBank
{
    class Program
    {
        static void Main(string[] args)
        {
            int price = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());

            
            if (n > 8)
            {
                Console.WriteLine("never");
            }
            else
            {
                int months = 30 - n; //дни без пиене
                int saved = (months * 2); //спестени
                int party = n * 5; //похарчени
                int diff = saved - party; // разлика

                double monthsTotal = (double)price / diff; // калкулира месеците общо
                int result = (int)Math.Ceiling(monthsTotal); //смята годините за изхода
                int year = result / 12;
                int mon = result % 12; // смята месеците за изхода

                Console.WriteLine("{0} years, {1} months",year,mon);
            }


        }
    }
}
