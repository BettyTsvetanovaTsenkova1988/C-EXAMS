﻿using System;

class BookProblem
{
    static void Main()
    {
        int pages = int.Parse(Console.ReadLine());
        int campingDays = int.Parse(Console.ReadLine());
        int npNormalDays = int.Parse(Console.ReadLine());

        int totalDayForReading = (30 - campingDays);
        if (totalDayForReading <= 0)
        {
            Console.WriteLine("never");
            return;
        }
        int readed = totalDayForReading * npNormalDays;
        int howMonths =(int) Math.Ceiling(pages / (double)readed);
        int years = howMonths / 12;
        int months = howMonths % 12;
        Console.WriteLine("{0} years {1} months", years, months);


    }
}
